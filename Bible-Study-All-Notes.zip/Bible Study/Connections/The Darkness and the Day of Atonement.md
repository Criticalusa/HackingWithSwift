---
tags: [connection, typology, atonement, crucifixion, temple, veil]
date: 2026-03-27
---

# The Darkness and the Day of Atonement

## The Event
From the **6th hour to the 9th hour** (noon to 3 PM), supernatural darkness covered the land (Matthew 27:45). At the 9th hour, Jesus cried out and died. At that instant, the temple veil was torn from top to bottom.

## The Day of Atonement Connection
These were the **exact hours** of the High Priest's work on Yom Kippur:
- **Noon (6th hour)**: High Priest begins the procession into the temple in full garments
- **3 PM (9th hour)**: High Priest enters the Most Holy Place to sprinkle blood on the mercy seat

Jesus was functioning as **both High Priest AND sacrifice** — offering His own blood in the heavenly tabernacle (Hebrews 9:11-12).

## The Veil Torn
- The temple veil was **60 feet tall, 4 inches thick**
- It separated the Holy Place from the Most Holy Place — **God from humanity**
- Only the High Priest could pass through it, **once a year**, on the Day of Atonement
- At Jesus' death, it was torn **from top to bottom** (Matthew 27:51)
- **From the top** = God Himself did the tearing. Not from the bottom (human effort).

## The Prophecy
Amos 8:9 — *"On that day, says the Lord GOD, I will make the sun go down at noon, and darken the earth in broad daylight."*

## The Meaning
The separation between God and humanity was **permanently removed**. The old system of annual atonement through a human priest was **finished**. Direct access to God's presence was now open to everyone through Christ.

## Connected Notes
- [[Passover Lamb Parallels (Exodus 12)]]
- [[Tetelestai — It Is Finished (G5055)]]
- [[Blood and Water — Adam 2.0 (John 19-34)]]

---
tags: [connection, covenant, marriage, israel, prophets, hosea]
date: 2026-03-25
---

# Israel as God's Wife — The Marriage Covenant

## The Wedding at Sinai (Exodus 19-24)
The covenant ceremony at Sinai mirrors an ancient Near Eastern **marriage covenant**:
- God "proposed" (Exodus 19:4-6) — *"You will be my treasured possession"*
- Israel said **"I do"**: *"All that the LORD has spoken, we will do"* (Exodus 24:3,7)
- Sealed with **blood** (Exodus 24:8) — the blood of the covenant

## God as Husband — The Prophets Speak

| Reference | Quote |
|-----------|-------|
| **Isaiah 54:5** | *"Your Maker is your **husband** — the LORD Almighty is his name"* |
| **Jeremiah 31:32** | *"I was a **husband** to them, declares the LORD"* |
| **Hosea 2:19-20** | *"I will betroth you to me forever... in faithfulness"* |
| **Ezekiel 16:8** | *"I spread the corner of my garment over you... I entered into a **covenant** with you and you became mine"* |

## The Betrayal
Israel committed spiritual adultery — worshiping idols, breaking the marriage covenant:
- **Ezekiel 16**: God found Israel as an abandoned baby, raised her, married her — then she prostituted herself
- **Jeremiah 3:6-10**: Israel "played the harlot" on every high hill and under every green tree
- **Hosea 1-3**: The entire book is a living parable of God's marriage to unfaithful Israel

## Hosea: The Living Parable
God commanded Hosea to **marry a prostitute** (Gomer) — then told him to **buy her back** after she was unfaithful (Hosea 3:1-2). This was God showing Israel: *"This is how I love you. You sold yourself, and I bought you back anyway."*

## The "Divorce" Problem
- **Jeremiah 3:8** — God gave faithless Israel a "certificate of divorce"
- **Deuteronomy 24:1-4** — Torah says a divorced woman can **never** return to her first husband
- **The impossible problem**: How can God take Israel back without breaking His own Law?

## The Solution: The New Covenant
- Death ends a marriage covenant (Romans 7:1-4)
- Through the cross, the old covenant "died" — freeing God to remarry His bride
- **Jeremiah 31:31-34**: *"I will make a **new covenant**... not like the covenant I made when I took them by the hand to lead them out of Egypt"*
- **Revelation 19:7**: *"The wedding of the Lamb has come, and his bride has made herself ready"*

God found a way to remarry His unfaithful bride **without breaking His own Torah**. That's the cross.

## Connected Notes
- [[Yisrael — Israel (H3478)]]
- [[Segullah (H5459)]]
- [[Israel's Threefold Identity at Sinai]]
- [[Not All Israel Is Israel — Romans 9-6]]

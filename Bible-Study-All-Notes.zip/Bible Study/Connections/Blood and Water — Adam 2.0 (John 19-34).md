---
tags: [connection, typology, genesis, john, adam, bride, church]
date: 2026-03-27
---

# Blood and Water — Adam 2.0 (John 19:34)

## The Event
> *"One of the soldiers pierced Jesus' side with a spear, and at once there came out **blood and water**."* (John 19:34)

## The Medical Reality
The separation of blood and serous fluid (pericardial/pleural effusion) proved Jesus was **truly dead**. The body was already showing signs of deterioration.

## The Genesis 2:21 Typology

| Adam (Genesis 2:21) | Jesus (John 19:34) |
|---------------------|---------------------|
| God put Adam into a **deep sleep** | Jesus entered the **deep sleep of death** |
| God opened Adam's **side** | The soldier opened Jesus' **side** |
| From Adam's side came his **bride** (Eve) | From Jesus' side came His **bride** (the Church) |
| Eve was formed from **bone and flesh** | The Church is formed from **blood** (atonement) and **water** (baptism/new life) |

## The Hebrew "Rib" Problem
The Hebrew word in Genesis 2:21 is **צֵּלָע** (*tsela*, H6763). It appears **35 times** in the OT and is **never translated "rib" anywhere else**. Every other time it means **"side"** or "beam" (as in the side of the tabernacle, the side of the ark, etc.).

God didn't take a rib. He opened Adam's **side**. Just as the soldier opened Jesus' side.

See [[Tsela — Side (H6763)]]

## The Church Fathers
- **Augustine**: "Just as Eve was created from Adam's side while he slept, so also while the Lord slept on the Cross, His side was transfixed, and the Sacraments flowed forth... whence the Church was born."
- **Chrysostom**: "From His side flowed blood and water — the very substance of the Church's life."

## The Awakening Parallel
Adam was put to sleep and **awoke to find a woman** beside him. Jesus entered the sleep of death and **awoke to find women** at the tomb — the first witnesses of the resurrection, an image of His faithful bride.

## Connected Notes
- [[Tsela — Side (H6763)]]
- [[Passover Lamb Parallels (Exodus 12)]]
- [[Feast of Firstfruits — The Resurrection]]
- [[The Darkness and the Day of Atonement]]

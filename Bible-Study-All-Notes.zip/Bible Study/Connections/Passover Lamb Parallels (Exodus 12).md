---
tags: [connection, typology, passover, exodus, crucifixion]
date: 2026-03-27
---

# Passover Lamb Parallels (Exodus 12)

## The Shadow and the Substance

| Exodus 12 (The Shadow) | Jesus (The Fulfillment) |
|------------------------|------------------------|
| Lamb must be **without blemish** (12:5) | Jesus was **without sin** (Heb 4:15, 1 Pet 1:19) |
| Selected on **Nisan 10** (12:3) | Jesus entered Jerusalem on **Nisan 10** (Palm Sunday) |
| Kept for **4 days** of inspection (12:6) | Jesus taught in temple for **4 days** — Pharisees couldn't find fault |
| Slaughtered at **3 PM** (12:6, "twilight") | Jesus died at **3 PM** (Mark 15:34-37) |
| **Not a bone** shall be broken (12:46) | Soldiers broke others' legs but **not Jesus'** (John 19:33-36) |
| Blood applied with **hyssop** (12:22) | Jesus given vinegar on a **hyssop branch** (John 19:29) |
| Blood on **doorposts** = protection from death | Blood on **cross beams** = protection from judgment |
| Blood applied in shape of a **cross** (top + two sides) | Blood shed on an actual **cross** |
| Eaten in haste — **deliverance from slavery** | Received by faith — **deliverance from sin** |
| "When I see the blood, I will **pass over** you" (12:13) | "Christ, our **Passover** lamb, has been sacrificed" (1 Cor 5:7) |

## The Timing Tea
The Passover lamb was staked out in the temple courtyard at **9 AM** and slaughtered at **3 PM**. Jesus was nailed to the cross at **9 AM** (Mark 15:25) and died at **3 PM** (Mark 15:34). Same schedule. 1,400 years apart.

## The Doorpost Cross
The blood in Exodus 12 was applied to the **top** (lintel) and **two sides** (doorposts) — forming the shape of a cross. This was 1,400 years before crucifixion was invented by the Persians.

## Connected Notes
- [[Tetelestai — It Is Finished (G5055)]]
- [[The Darkness and the Day of Atonement]]
- [[Feast of Firstfruits — The Resurrection]]

---
tags: [connection, typology, resurrection, feasts, firstfruits, leviticus]
date: 2026-03-27
---

# Feast of Firstfruits — The Resurrection

## The Old Testament Foundation (Leviticus 23:10-14)
On the day after the Sabbath during Passover week, the priest would wave the **first sheaf of grain** before God — a thanksgiving offering and a **guarantee** that the full harvest was coming.

## The Timing
- Passover lambs slaughtered: **Nisan 14** (Friday — Jesus dies)
- First day of Unleavened Bread: **Nisan 15** (Saturday — Jesus in the tomb)
- Feast of Firstfruits: **Nisan 16** (Sunday — **Jesus rises**)

Jesus rose on the **exact day** the priest was waving the first sheaf of grain before God.

## Paul's Connection (1 Corinthians 15:20-23)
> *"But Christ has indeed been raised from the dead, the **firstfruits** of those who have fallen asleep."*

Paul uses harvest language deliberately:
- **Firstfruits** = the first portion of the crop, proving the rest is coming
- Jesus's resurrection = the **guarantee** of our resurrection
- "If the cross is the payment, the resurrection is the **receipt**"

## The Imagery
Seeds that **died in the ground** arose in **new life** and were **lifted up** before God. That's literally what happened Easter morning.

## Key Distinction
Jesus wasn't the first person raised from the dead (Lazarus, widow's son, etc.). But those were **resuscitations** — they died again. Jesus was the first **resurrection** — raised in a new, eternal, glorified body. That's why He's the "firstfruits" — He's the first of a completely new kind of harvest.

## Connected Notes
- [[Passover Lamb Parallels (Exodus 12)]]
- [[Anastasis — Resurrection (G386)]]
- [[Blood and Water — Adam 2.0 (John 19-34)]]

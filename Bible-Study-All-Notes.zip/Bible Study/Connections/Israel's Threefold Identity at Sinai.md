---
tags: [connection, covenant, sinai, identity, israel]
date: 2026-03-25
---

# Israel's Threefold Identity at Sinai

## The Passage: Exodus 19:5-6
> *"If you obey my voice and keep my covenant, you shall be my **treasured possession** among all peoples, for all the earth is mine; and you shall be to me a **kingdom of priests** and a **holy nation**."*

## The Three Titles

### 1. סְגֻלָּה (Segullah) — Treasured Possession
See [[Segullah (H5459)]]
- *"You are mine"*
- Not chosen for merit but for love (Deuteronomy 7:7-8)
- The crown jewel in God's vault

### 2. מַמְלֶכֶת כֹּהֲנִים (Mamlechet Kohanim) — Kingdom of Priests
- *"You mediate between me and the nations"*
- Israel wasn't chosen for exclusivity — they were chosen for **service**
- A priest stands between God and people, representing each to the other
- Fulfilled in 1 Peter 2:9: *"You are a royal priesthood"*

### 3. גּוֹי קָדוֹשׁ (Goy Kadosh) — Holy Nation
- *"You are set apart"*
- *Kadosh* doesn't primarily mean "morally perfect" — it means **"separated, distinct, other"**
- Israel was meant to be visibly different from the nations

## The NT Echo
**1 Peter 2:9** takes all three titles and applies them to the Church:
> *"You are a chosen people, a **royal priesthood**, a **holy nation**, God's **special possession**"*

The same identity. The same calling. Expanded to include all who are grafted in.

## Connected Notes
- [[Yisrael — Israel (H3478)]]
- [[Segullah (H5459)]]
- [[Israel as God's Wife — The Marriage Covenant]]

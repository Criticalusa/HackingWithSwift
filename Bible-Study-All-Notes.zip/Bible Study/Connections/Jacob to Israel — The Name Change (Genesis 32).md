---
tags: [connection, name-study, genesis, transformation, peniel]
date: 2026-03-25
---

# Jacob to Israel — The Name Change (Genesis 32:22-32)

## The Setup
Jacob is alone at night by the Jabbok River, terrified of meeting Esau the next day. He has sent his family ahead. For the first time, he has nothing to scheme with — no tricks, no leverage. Just him and the dark.

## The Wrestling Match
A "man" wrestled him until dawn (Genesis 32:24). This was:
- A **man** (Genesis 32:24)
- An **angel** (Hosea 12:4)
- **God Himself** — Jacob says: "I have seen God face to face" (Genesis 32:30)

## The Wound
God **dislocated Jacob's hip** (Genesis 32:25). He would limp for the rest of his life. The wound wasn't punishment — it was a **memorial**. Every step Jacob took for the rest of his life reminded him: I met God and survived.

## The Question
> **"What is your name?"** (Genesis 32:27)

God wasn't asking for information. He was making Jacob **confess his identity**:
- "My name is Jacob" = "I am the deceiver" = "I am the crooked one"
- Only after owning who he was could God give him who he was meant to be

## The Renaming
> *"Your name shall no longer be called Jacob, but **Israel**, for you have striven with God and with men, and have **prevailed**."* (Genesis 32:28)

## The Place: Peniel (פְּנִיאֵל)
Jacob named the place **Peniel** — "Face of God." Meaning: *"I have seen God **face to face**, yet my life has been preserved."*

## The Pattern
| Before | After |
|--------|-------|
| Jacob (Crooked) | Israel (Upright/Prince of God) |
| Running from Esau | Walking toward Esau |
| Scheming | Surrendering |
| Whole body, broken spirit | Broken body, whole spirit |

## The Tea
Jacob **refused to let go**: *"I will not let you go unless you bless me"* (Genesis 32:26). This is the heart of what "Israel" means — not someone who fought God and won, but someone who **held on to God and wouldn't let go until they were transformed**.

## Connected Notes
- [[Yisrael — Israel (H3478)]]
- [[Ya'akov — Jacob (H3290)]]
- [[Sarah — To Wrestle (H8280)]]
- [[Jeshurun (H3484)]]

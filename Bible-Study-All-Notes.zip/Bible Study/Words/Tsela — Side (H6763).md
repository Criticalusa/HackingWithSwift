---
tags: [word-study, hebrew, strongs-H6763, genesis, typology]
strongs: H6763
hebrew: צֵּלָע
transliteration: tsela
date: 2026-03-27
---

# Tsela (צֵּלָע) — "Side" — H6763

## The Problem
In Genesis 2:21, English Bibles say God took Adam's **"rib."** But the Hebrew word *tsela* appears **35 times** in the Old Testament and is **never translated "rib" anywhere else**.

## What It Actually Means
Every other occurrence means **"side"** or **"beam"**:
- **Exodus 25:12** — the *sides* of the ark
- **Exodus 26:20** — the *side* of the tabernacle
- **1 Kings 6:5** — the *side chambers* of the temple
- **Ezekiel 41:6** — the *side rooms* of the temple

## Why This Matters
God didn't take a rib from Adam. He opened Adam's **side** — and from that opened side, He formed the bride.

1,400+ years later, a soldier opened Jesus' **side** with a spear (John 19:34), and from it flowed blood and water — the elements that form His bride, the Church.

The typology only works if *tsela* means "side." And it does — everywhere except the one verse English translators chose to say "rib."

See [[Blood and Water — Adam 2.0 (John 19-34)]]

## Connected Notes
- [[Blood and Water — Adam 2.0 (John 19-34)]]
- [[Passover Lamb Parallels (Exodus 12)]]

---
tags: [word-study, greek, strongs-G386, resurrection]
strongs: G386
greek: ἀνάστασις
transliteration: anastasis
root: anistēmi (G450) — ana "up/again" + histēmi "to stand"
date: 2026-03-27
---

# Anastasis (ἀνάστασις) — Resurrection — G386

## Definition
- Literally: **"a standing up again"** — from *ana* (up/again) + *stasis* (standing)
- The act of rising from the dead into a new, glorified body

## The Key Verse
> **John 11:25** — Jesus said, *"I **AM** the resurrection (anastasis) and the life."*

Jesus doesn't say "I will give you resurrection." He says **"I AM the resurrection."** The resurrection isn't an event waiting in the future — it's a **Person** standing in front of Martha.

## Hebrew Equivalent
- **תקומה** (*tequmah*) — from the root **קום** (*qum*) — "to stand up, to rise"
- Though the word "resurrection" doesn't appear in the Hebrew OT, the concept does:
  - **Hosea 13:14** — *"From the power of the grave I will redeem them; from death I will recover them"*
  - **Daniel 12:2** — *"Many of those who sleep in the dust of the earth shall awake"*

## Resurrection vs. Resuscitation
| Resuscitation | Resurrection |
|---------------|-------------|
| Same body | New glorified body |
| Will die again | Will never die again |
| Lazarus, widow's son | **Jesus** — the first and only (so far) |

Jesus is the **firstfruits** (1 Cor 15:20) — the first of a new kind of life.

## Connected Notes
- [[Feast of Firstfruits — The Resurrection]]
- [[Tetelestai — It Is Finished (G5055)]]

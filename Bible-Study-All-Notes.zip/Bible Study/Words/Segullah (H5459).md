---
tags: [word-study, hebrew, strongs-H5459, covenant, election]
strongs: H5459
hebrew: סְגֻלָּה
transliteration: segullah
date: 2026-03-25
---

# Segullah (סְגֻלָּה) — H5459

## Definition
- **Meaning**: Treasured possession, special property, personal treasure
- **Root**: from a word meaning "to shut up, reserve" — something guarded and kept
- Not just any possession — the **one thing a king values above everything else**

## Key Appearances
- **Exodus 19:5** — *"You shall be my segullah among all peoples"*
- **Deuteronomy 7:6** — *"The LORD has chosen you to be a people for His segullah"*
- **Deuteronomy 14:2** — *"The LORD has chosen you to be a people for Himself, a segullah"*
- **Deuteronomy 26:18** — *"The LORD has declared you to be His segullah"*
- **Malachi 3:17** — *"They shall be Mine... My segullah... in the day when I act"*
- **1 Peter 2:9** (NT echo) — *"a people for God's own possession"* (Greek: *peripoiēsis*)

## What This Meant at Sinai
God gave Israel three covenant titles in Exodus 19:5-6:
1. **Segullah** — Treasured Possession — *"You are mine"*
2. **Mamlechet Kohanim** — Kingdom of Priests — *"You mediate between me and the nations"*
3. **Goy Kadosh** — Holy Nation — *"You are set apart"*

## The Heart of Election
Deuteronomy 7:7-8 explains WHY: *"The LORD did not set his love on you nor choose you because you were more in number... but because the LORD loves you."* The election wasn't about Israel's merit — it was about God's love.

## Connected Notes
- [[Yisrael — Israel (H3478)]]
- [[Israel's Threefold Identity at Sinai]]

---
tags: [word-study, hebrew, strongs-H3484, name-study, jeshurun, israel]
strongs: H3484
hebrew: יְשֻׁרוּן
transliteration: Yeshurun
root: yashar (H3474) "upright, straight, righteous"
date: 2026-03-25
---

# Jeshurun (יְשֻׁרוּן) — H3484

## Definition
- **Meaning**: "The Upright One" / "The Straight One"
- **Root**: יָשָׁר (*yashar*) — upright, straight, righteous
- **Septuagint translation**: ἠγαπημένος (*egapemenos*) — **"Beloved One"** (from *agape*)
- A poetic **term of endearment** for Israel

## The Tea
The consonants of **Jeshurun** (ישרון) and **Israel** (ישראל) are nearly identical. They're the same name from different angles. God hid "The Upright One" inside "The Wrestler with God."

Jacob = "Crooked." Jeshurun = "Straight." **The whole gospel in a name change.**

## Appearances (only 4 times)
1. **Deuteronomy 32:15** — *"Jeshurun grew fat and kicked"* — used in **ironic rebuke** (the "upright one" became anything but)
2. **Deuteronomy 33:5** — *"He was king over Jeshurun"* — God as king of His beloved
3. **Deuteronomy 33:26** — *"There is no one like the God of Jeshurun, who rides across the heavens to help you"*
4. **Isaiah 44:2** — *"Do not be afraid, Jacob my servant, Jeshurun, whom I have chosen"*

## Scholarly Views
- Calvin: "By using 'upright' for Israel, the author ironically taunts them with having departed from rectitude"
- Waller: "Jeshurun is a diminutive — a term of endearment: the beloved Israel"
- Bacher: "This new name stands in contrast to Jacob, 'the supplanter.' Israel is given a new name, 'the upright one,' and with the new name goes a new chance in life"

## Connected Notes
- [[Yisrael — Israel (H3478)]]
- [[Ya'akov — Jacob (H3290)]]

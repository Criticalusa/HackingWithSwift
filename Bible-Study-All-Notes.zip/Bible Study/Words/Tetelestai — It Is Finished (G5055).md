---
tags: [word-study, greek, strongs-G5055, crucifixion]
strongs: G5055
greek: τετέλεσται
transliteration: tetelestai
root: teleō (G5055) from telos (G5056) — "end, purpose, goal"
date: 2026-03-27
---

# Tetelestai (τετέλεσται) — "It Is Finished" — G5055

## The Popular Myth
Many teach that *tetelestai* was a Roman accounting term meaning "paid in full" stamped on debt receipts. Scholars at Biola University have shown this is based on a misreading — the word on ancient papyrus receipts was actually **tetelōnētai** (a tax term), a different Greek word entirely.

## What It Actually Means
*Tetelestai* is the perfect passive indicative of *teleō* — to bring to a **telos** (τέλος): an end, a purpose, a completion, a perfection.

It means: **"It has been brought to its intended goal. It is accomplished. It is complete."**

## What Jesus Was Declaring
Not just one thing — everything:
- Every **Old Testament prophecy** about the Messiah: fulfilled (John 19:28)
- Every **type and shadow**: reached its reality
- The **entire mission** the Father gave Him: accomplished (John 4:34, 17:4)
- The old covenant sacrificial system: **finished** — something new has begun

## The Word in John's Gospel
John uses *teleō* and its derivatives as a theme:
- **John 4:34** — "My food is to do the will of Him who sent me and to **finish** (*teleioō*) His work"
- **John 17:4** — "I have **finished** (*teleioō*) the work you gave me to do"
- **John 19:28** — "Knowing that all things had been **accomplished** (*teleō*), to fulfill the Scripture..."
- **John 19:30** — "**Tetelestai.**"

## Grammar Note
Perfect tense = completed action with **ongoing results**. It is finished — and it **stays** finished.

## Connected Notes
- [[Passover Lamb Parallels (Exodus 12)]]
- [[The Darkness and the Day of Atonement]]
- [[Anastasis — Resurrection (G386)]]

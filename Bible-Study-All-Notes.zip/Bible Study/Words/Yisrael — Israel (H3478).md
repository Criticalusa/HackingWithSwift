---
tags: [word-study, hebrew, strongs-H3478, name-study, israel]
strongs: H3478
hebrew: יִשְׂרָאֵל
transliteration: Yisra'el
root: sarah (H8280) "to wrestle/contend" + El (H410) "God"
date: 2026-03-25
---

# Yisra'el (יִשְׂרָאֵל) — Israel — H3478

## Definition
A compound name with **four layers of meaning**:

| Reading | Meaning |
|---------|---------|
| **Yisra-El** | "He wrestles/strives with God" |
| **Yisar-El** | "God strives/persists" |
| **Sar-El** | "Prince of God" (from *sar* = prince) |
| **Yashar-El** | "Upright of God" (from *yashar* = straight) |

## Root Components
1. **שָׂרָה (sarah, H8280)** — to contend, wrestle, persist, prevail. Masculine form *sar* = prince
2. **אֵל (El, H410)** — God, the Mighty One. Appears 6,581 times in the Hebrew Bible

## The Yod Prefix (י)
The first letter *Yod* is a future-tense prefix: "he will." So Israel = "He **will** wrestle/rule/be upright with God." It's not just a past event — it's a **prophetic identity**.

## Pictographic Letters
| Letter | Pictograph | Meaning |
|--------|-----------|---------|
| י (Yod) | Hand | God's work/deed |
| שׂ (Shin) | Teeth/fire | Consume, divine power |
| ר (Resh) | Head of man | Mind, a bowed head |
| א (Aleph) | Ox head | Strength, yoke |
| ל (Lamed) | Shepherd's staff | Authority, teaching |

Hidden message: **"God's hand overcomes the mind of man through the Shepherd's authority."**

## First Mention
**Genesis 32:28** — God renames Jacob after the wrestling match at Peniel: "Your name shall no longer be called Jacob, but Israel, for you have striven with God and with men, and have prevailed."

## The Contrast
| Jacob (יַעֲקֹב) | Israel (יִשְׂרָאֵל) |
|---|---|
| Heel-grabber | Prince of God |
| Crooked (*eqev*) | Upright (*yashar*) |
| Deceiver | Overcomer |
| Who he was | Who God made him |

## Connected Notes
- [[Ya'akov — Jacob (H3290)]]
- [[Jeshurun (H3484)]]
- [[Segullah (H5459)]]
- [[Sarah — To Wrestle (H8280)]]
- [[Jacob to Israel — The Name Change (Genesis 32)]]
- [[Israel as God's Wife — The Marriage Covenant]]

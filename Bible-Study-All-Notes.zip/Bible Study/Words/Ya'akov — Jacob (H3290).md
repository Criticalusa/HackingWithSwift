---
tags: [word-study, hebrew, strongs-H3290, name-study, jacob]
strongs: H3290
hebrew: יַעֲקֹב
transliteration: Ya'akov
root: aqav (H6117) "to seize by the heel, supplant"
date: 2026-03-25
---

# Ya'akov (יַעֲקֹב) — Jacob — H3290

## Definition
- **Literal**: "Heel-catcher" — born gripping Esau's heel (Genesis 25:26)
- **Figurative**: "Supplanter" / "Deceiver" / "Crooked"
- **Root**: עָקַב (*aqav*, H6117) — to swell out, to seize by the heel, to circumvent, to overreach

## The Key Insight
The word עָקֵב (*eqev*) means both "heel" and **"crooked."** Jacob's name literally means "the crooked one." This makes the name change to Israel — which connects to *yashar* ("straight/upright") — all the more powerful. God renamed **Crooked** as **Straight**.

## Esau's Commentary
> *"Is he not rightly named Jacob? For he has supplanted me these two times."* (Genesis 27:36)

Even Esau understood: the name was the man.

## The Transformation
God's first question at Peniel: **"What is your name?"** (Genesis 32:27). Not for information — for **confession**. "I am Jacob" = "I am the deceiver." Only after owning his old identity could Jacob receive his new one.

## Connected Notes
- [[Yisrael — Israel (H3478)]]
- [[Jacob to Israel — The Name Change (Genesis 32)]]
- [[Jeshurun (H3484)]]

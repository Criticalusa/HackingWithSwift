---
tags: [word-study, hebrew, strongs-H8280, root-word]
strongs: H8280
hebrew: שָׂרָה
transliteration: sarah
date: 2026-03-25
---

# Sarah — To Wrestle/Contend (שָׂרָה) — H8280

## Definition
- To contend, wrestle, persist, prevail, strive
- Related to שַׂר (*sar*) — prince, ruler, minister
- Related to שָׂרָה (*Sarah*) — princess

## The Root of "Israel"
This is the verb embedded in the name Israel (יִשְׂרָאֵל). *Sarah* + *El* = Israel. The one who **contends/prevails** with **God**.

## The Double Meaning
The same root gives us both:
- **Wrestling/struggling** — the raw fight with God
- **Ruling/princehood** — the authority that comes FROM the fight

This is the genius of the name: you don't become a prince of God by avoiding the struggle. You become a prince **through** the struggle. The wrestling IS the promotion.

## Connection to the Name "Sarah"
Abraham's wife Sarah (שָׂרָה) shares this root. Her name means "Princess." She too received a name change — from Sarai ("my princess") to Sarah ("princess" — universalized). Both name changes in this family involved the same Hebrew root and signaled a transformation of identity by God.

## Connected Notes
- [[Yisrael — Israel (H3478)]]
- [[Ya'akov — Jacob (H3290)]]
- [[Jacob to Israel — The Name Change (Genesis 32)]]

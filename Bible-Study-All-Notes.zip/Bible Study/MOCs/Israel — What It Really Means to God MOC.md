---
tags: [MOC, topic-study, name-study, israel, covenant]
type: map-of-content
date: 2026-03-25
---

# What Israel Really Means to God — Topic Study MOC

> From "Crooked" (Jacob) to "Upright One" (Jeshurun) — a love story encoded in a name.

---

## The Names
| Name | Hebrew | Meaning | Identity |
|------|--------|---------|----------|
| [[Ya'akov — Jacob (H3290)]] | יַעֲקֹב | Heel-grabber / Deceiver / Crooked | Who he was |
| [[Yisrael — Israel (H3478)]] | יִשְׂרָאֵל | Wrestles with God / Prince of God / Upright of God | Who God made him |
| [[Jeshurun (H3484)]] | יְשֻׁרוּן | The Upright One / Beloved | God's pet name for Israel |

---

## Word Studies
| Word | Strong's | Key Insight |
|------|----------|-------------|
| [[Yisrael — Israel (H3478)]] | H3478 | Four meanings layered: wrestler, prince, God strives, upright of God |
| [[Ya'akov — Jacob (H3290)]] | H3290 | "Crooked" — the identity God replaced |
| [[Jeshurun (H3484)]] | H3484 | God's secret name for Israel: "My Upright/Beloved One" |
| [[Segullah (H5459)]] | H5459 | "Treasured possession" — what Israel is to God |
| [[Sarah — To Wrestle (H8280)]] | H8280 | Root of "Israel" — to contend, persist, prevail |

---

## Connections & Patterns
- [[Jacob to Israel — The Name Change (Genesis 32)]] — The wrestling match that changed everything
- [[Israel as God's Wife — The Marriage Covenant]] — Sinai as wedding, Hosea as living parable, divorce and remarriage
- [[Israel's Threefold Identity at Sinai]] — Segullah, Kingdom of Priests, Holy Nation
- [[Not All Israel Is Israel — Romans 9-6]] — Remnant theology and the spiritual weight of the name

---

## The "Tea" (Share-Worthy Discovery)
God has a **secret pet name** for Israel: **Jeshurun** — "The Upright One" / "My Beloved." The consonants of Jeshurun (ישרון) and Israel (ישראל) are nearly identical. Jacob means "crooked." Jeshurun means "straight." God renamed the Crooked One as the Straight One. The whole gospel in a name change.

---

## The Thread: Genesis to Revelation
| Stage | Identity |
|-------|----------|
| Genesis 32 | One man renamed — "You have wrestled with God" |
| Exodus 19 | A nation claimed — "My treasured possession" |
| Deuteronomy 33 | A beloved called — "Jeshurun, the Upright One" |
| Isaiah 54 | A wife cherished — "Your Maker is your husband" |
| Hosea | A bride redeemed — bought back from prostitution |
| Romans 9 | A remnant refined — "Not all Israel is Israel" |
| Revelation 21 | A bride restored — "The wife of the Lamb" |

---

## Go Deeper
- **Passage Comparison**: Genesis 32:22-32 vs Hosea 12:3-5
- **Word Study**: [[Segullah (H5459)]] — trace through Exodus, Deuteronomy, Malachi 3:17, 1 Peter 2:9
- **Topic Study**: The Marriage Covenant at Sinai — Exodus 19-24 as ancient wedding ceremony

---

## Meditate On
> **"What is your name?"** — God's question to Jacob wasn't curiosity. It was an invitation to confess who you've been, so He can rename you into who you're becoming.

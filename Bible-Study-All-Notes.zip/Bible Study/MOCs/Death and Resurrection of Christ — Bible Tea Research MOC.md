---
tags: [MOC, topic-study, death, resurrection, christ, passover, feasts, typology]
type: map-of-content
date: 2026-03-27
---

# Death & Resurrection of Christ — Bible Tea Research MOC

> The crucifixion and resurrection weren't random events — they were surgically placed on God's 1,400-year-old prophetic feast calendar.

---

## The 7 Layers of Tea

| # | Discovery | Key Connection |
|---|-----------|---------------|
| 1 | [[Jesus Died on God's Calendar]] | Passover → Unleavened Bread → Firstfruits = Death → Burial → Resurrection |
| 2 | [[Passover Lamb Parallels (Exodus 12)]] | No bones broken, hyssop, blood on doorposts shaped like a cross |
| 3 | [[Tetelestai — It Is Finished (G5055)]] | Not "paid in full" (that's a myth) — means "brought to its purpose/completion" |
| 4 | [[The Darkness and the Day of Atonement]] | 6th-to-9th-hour darkness = High Priest entering Holy of Holies |
| 5 | [[Feast of Firstfruits — The Resurrection]] | Jesus rose ON Firstfruits — the guarantee of the coming harvest |
| 6 | [[Blood and Water — Adam 2.0 (John 19-34)]] | Adam's side → Eve (bride); Jesus' side → Church (bride). Hebrew "tsela" = side, not rib |
| 7 | [[Anastasis — Resurrection (G386)]] | "I AM the resurrection" — not an event, a Person |

---

## Word Studies
| Word | Strong's | Key Insight |
|------|----------|-------------|
| [[Tetelestai — It Is Finished (G5055)]] | G5055 | "Brought to its *telos* (purpose)" — every prophecy, type, and mission completed |
| [[Anastasis — Resurrection (G386)]] | G386 | "To stand up again" — Jesus IS the resurrection, not just its source |
| [[Tsela — Side (H6763)]] | H6763 | Translated "rib" only in Genesis 2:21 — everywhere else it means "side" |

---

## Connections
- [[Passover Lamb Parallels (Exodus 12)]] — 12+ point-by-point fulfillment
- [[The Darkness and the Day of Atonement]] — Jesus as both High Priest and sacrifice
- [[Blood and Water — Adam 2.0 (John 19-34)]] — Genesis 2:21 typology
- [[Feast of Firstfruits — The Resurrection]] — Leviticus 23 → 1 Corinthians 15:20

---

## Bible Tea Teaching Framework
- **Hook**: "Jesus didn't die on a random Friday. He died at 3 PM on Passover — the exact second the lamb was being slaughtered in the temple next door."
- **Setup**: Walk through Exodus 12 Passover instructions
- **Reveal**: Lay the parallels side by side — let the pattern build
- **Landing**: "This was a 1,400-year-old blueprint. The shadow was always pointing to the substance."

---

## Go Deeper
- **Word Study**: [[Tetelestai — It Is Finished (G5055)]] — trace *teleō* through John's Gospel
- **Passage Comparison**: Genesis 2:21 vs John 19:34 — the two "opened sides"
- **Topic Study**: The 7 Feasts of Leviticus 23 — how Jesus fulfills each one

---

## Meditate On
> The Passover lamb was staked out at 9 AM and slaughtered at 3 PM. Jesus was nailed to the cross at 9 AM and died at 3 PM. 1,400 years apart. Same clock. Same God.
